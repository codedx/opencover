#include <googletest/gtest.hpp>

TEST(MD_funConnectionImportTest, SetAndGetParametersNumberTest)
{
}
